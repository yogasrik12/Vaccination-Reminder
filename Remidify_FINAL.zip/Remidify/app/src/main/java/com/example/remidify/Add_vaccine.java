package com.example.remidify;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;

import java.util.ArrayList;
import java.util.Calendar;

public class Add_vaccine extends AppCompatActivity {

    DBHelper db;

    ListView listPatients, listRecords;
    EditText vaccineName, vaccineType, takenDate, dueDate, notes;
    Button btnSave, btnUpdate, btnDelete;

    int selectedPatientId = -1;
    int selectedRecordId = -1;
    String selectedPatientName = "";

    ArrayList<String> names = new ArrayList<>();
    ArrayList<Integer> ids = new ArrayList<>();

    ArrayList<String> records = new ArrayList<>();
    ArrayList<Integer> recordIds = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vaccine);

        db = new DBHelper(this);

        // ====== UI BIND ======
        listPatients = findViewById(R.id.listPatients);
        listRecords  = findViewById(R.id.listRecords);

        vaccineName = findViewById(R.id.editVaccineName);
        vaccineType = findViewById(R.id.editVaccineType);
        takenDate   = findViewById(R.id.editTakenDate);
        dueDate     = findViewById(R.id.editDueDate);
        notes       = findViewById(R.id.editNotes);

        btnSave   = findViewById(R.id.btnSaveRecord);
        btnUpdate = findViewById(R.id.btnUpdateRecord1);
        btnDelete = findViewById(R.id.btnDeleteRecord);

        // ===== LOAD PATIENTS =====
        loadPatients();

        // ===== SELECT PATIENT =====
        listPatients.setOnItemClickListener((p,v,pos,id)->{

            selectedPatientId   = ids.get(pos);
            selectedPatientName = names.get(pos);
            selectedRecordId   = -1;

            Toast.makeText(this,
                    "Patient Selected",
                    Toast.LENGTH_SHORT).show();

            loadRecords(selectedPatientId);
        });

        // ===== SELECT RECORD =====
        listRecords.setOnItemClickListener((p,v,pos,id)->{

            selectedRecordId = recordIds.get(pos);

            Cursor c = db.getSingleRecord(selectedRecordId);

            if(c.moveToFirst()){

                vaccineName.setText(c.getString(3));
                vaccineType.setText(c.getString(4));
                takenDate.setText(c.getString(5));
                dueDate.setText(c.getString(6));
                notes.setText(c.getString(7));
            }

            c.close();
        });

        // ===== CALENDAR =====
        takenDate.setOnClickListener(v -> showCalendar(takenDate));
        dueDate.setOnClickListener(v -> showCalendar(dueDate));

        // ===== SAVE =====
        btnSave.setOnClickListener(v -> saveRecord());

        // ===== UPDATE =====
        btnUpdate.setOnClickListener(v -> updateRecord());

        // ===== DELETE =====
        btnDelete.setOnClickListener(v -> deleteRecord());
    }

    // ====================================================
    // LOAD PATIENTS
    // ====================================================
    private void loadPatients(){

        names.clear();
        ids.clear();

        Cursor cursor = db.getAllPatients();

        while(cursor.moveToNext()){
            ids.add(cursor.getInt(0));
            names.add(cursor.getString(1));
        }

        cursor.close();

        listPatients.setAdapter(
                new ArrayAdapter<>(this,
                        android.R.layout.simple_list_item_1,
                        names));
    }

    // ====================================================
    // LOAD RECORDS
    // ====================================================
    private void loadRecords(int patientId){

        records.clear();
        recordIds.clear();

        Cursor cursor = db.getPatientRecords(patientId);

        while(cursor.moveToNext()){

            int id = cursor.getInt(0);
            String vaccine = cursor.getString(3);
            String taken = cursor.getString(5);

            recordIds.add(id);
            records.add(vaccine + " (" + taken + ")");
        }

        cursor.close();

        listRecords.setAdapter(
                new ArrayAdapter<>(this,
                        android.R.layout.simple_list_item_1,
                        records));
    }

    // ====================================================
    // CALENDAR
    // ====================================================
    private void showCalendar(EditText e){

        Calendar c = Calendar.getInstance();

        new DatePickerDialog(this,
                (view,year,month,day)->
                        e.setText(day+"/"+(month+1)+"/"+year),
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)).show();
    }

    // ====================================================
    // SAVE
    // ====================================================
    private void saveRecord(){

        if(selectedPatientId == -1){
            Toast.makeText(this,
                    "Select Patient First",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        boolean inserted = db.insertPatientRecord(
                selectedPatientId,
                selectedPatientName,
                vaccineName.getText().toString(),
                vaccineType.getText().toString(),
                takenDate.getText().toString(),
                dueDate.getText().toString(),
                notes.getText().toString()
        );

        Toast.makeText(this,
                inserted ? "Saved" : "Failed",
                Toast.LENGTH_SHORT).show();

        loadRecords(selectedPatientId);
    }

    // ====================================================
    // UPDATE
    // ====================================================
    private void updateRecord(){

        if(selectedRecordId == -1){
            Toast.makeText(this,
                    "Select Record First",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        boolean ok = db.updatePatientRecord(
                selectedRecordId,
                vaccineName.getText().toString(),
                vaccineType.getText().toString(),
                takenDate.getText().toString(),
                dueDate.getText().toString(),
                notes.getText().toString()
        );

        Toast.makeText(this,
                ok ? "Updated" : "Failed",
                Toast.LENGTH_SHORT).show();

        loadRecords(selectedPatientId);
    }

    // ====================================================
    // DELETE
    // ====================================================
    private void deleteRecord(){

        if(selectedRecordId == -1){
            Toast.makeText(this,
                    "Select Record First",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        boolean ok = db.deletePatientRecord(selectedRecordId);

        Toast.makeText(this,
                ok ? "Deleted" : "Failed",
                Toast.LENGTH_SHORT).show();

        loadRecords(selectedPatientId);
    }
}
