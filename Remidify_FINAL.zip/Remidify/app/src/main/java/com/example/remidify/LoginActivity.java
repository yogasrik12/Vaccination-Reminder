package com.example.remidify;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText etUsername,etPassword;
    Button btnSignIn,btnDoc;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername=findViewById(R.id.etUsername);
        etPassword=findViewById(R.id.etPassword);
        btnSignIn=findViewById(R.id.btnSignIn);
        btnDoc=findViewById(R.id.btnDoctor);
        db=new DBHelper(this);

        btnSignIn.setOnClickListener(v->loginUser());
        btnDoc.setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, Doctor_login.class)));
    }


    private void loginUser(){

        String u=etUsername.getText().toString();
        String p=etPassword.getText().toString();

        if(TextUtils.isEmpty(u)||
                TextUtils.isEmpty(p)){

            Toast.makeText(this,
                    "Enter all fields",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if(db.checkUser(u,p)){

            // SAVE SESSION
            SharedPreferences sp=
                    getSharedPreferences(
                            "LoginSession",MODE_PRIVATE);

            sp.edit()
                    .putString("username",u)
                    .putBoolean("isLoggedIn",true)
                    .apply();

            Toast.makeText(this,
                    "Login Success",
                    Toast.LENGTH_SHORT).show();

            startActivity(new Intent(
                    LoginActivity.this,
                    user_dashboard.class));

            finish();

        }else{

            Toast.makeText(this,
                    "Invalid Credentials",
                    Toast.LENGTH_SHORT).show();
        }
    }
}