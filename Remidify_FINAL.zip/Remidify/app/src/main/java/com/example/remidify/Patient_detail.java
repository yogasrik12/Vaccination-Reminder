package com.example.remidify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Patient_detail extends AppCompatActivity {

    DBHelper db;
    LinearLayout recordsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_detail);

        db = new DBHelper(this);
        recordsContainer = findViewById(R.id.recordsContainer);

        int patientId =
                getIntent().getIntExtra("patient_id",-1);

        loadRecords(patientId);
    }

    private void loadRecords(int id){

        Cursor cursor = db.getPatientRecords(id);

        while(cursor.moveToNext()){

            int recordId = cursor.getInt(0);
            String vName = cursor.getString(3);
            String taken = cursor.getString(5);
            String due = cursor.getString(6);

            TextView tv = new TextView(this);
            tv.setPadding(30,20,30,20);
            tv.setTextSize(16);

            tv.setText(
                    "💉 " + vName +
                            "\nTaken : " + taken +
                            "\nDue : " + due
            );

            // CLICK → UPDATE PAGE
            tv.setOnClickListener(v -> {

                Intent i = new Intent(
                        Patient_detail.this,
                        Update_Delete_Vaccine.class);

                i.putExtra("record_id", recordId);
                startActivity(i);
            });

            recordsContainer.addView(tv);
        }

        cursor.close();
    }
}
